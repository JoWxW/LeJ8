/**
 * 
 */
package model.enumeration;

/**
 *  <b>Description</b>
 *  La position de la carte
 *
 */
public enum Etat {
	enAttend, aLaMain, surTable
}
