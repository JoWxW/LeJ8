/**
 * 
 */
package enumeration;

/**
 * @author wxw
 *
 */
public enum Etat {
	enAttend, aLaMain, surTable
}
