package model.enumeration;
/**
 *  <b>Description</b>
 *  Le stratégie s'applique au joueur virtuel
 *
 */

public enum Strategie {
      strategieSimple,strategieMoyenne,strategieDifficile;
}
