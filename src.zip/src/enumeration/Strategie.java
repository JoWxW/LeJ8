package enumeration;

public enum Strategie {
      strategieSimple,strategieMoyenne,strategieDifficile;
}
